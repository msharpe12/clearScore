/*
 * Author: Michael Sharpe
 * Project: ClearScore Interview
 * Date: 11/11/2018 
 * 
 * Note: Test result output to 'TestResultOutput' folder within project
 * Dependencies: TestNG and Selenium
 */

package clearscore.interview;

import java.util.HashMap;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Task3TestHarness {
	
	private ClearScoreLogic clearScoreLogic;
	private String websiteURL;
	private String cookieButtonCSSSelector;
	private String scoreSliderCSSSelector;
	private String currentScoreSliderValueCSSSelector;
	private String goalSliderCSSSelector;
	private String currentGoalSliderValueCSSSelector;
	private String averageInterestCurrentCSSSelector;
	private String averageInterestGoalCSSSelector;
	private String annualCostCurrentCSSSelector;
	private String annualCostGoalCSSSelector;
	private String cardsAvaliableCurrentCSSSelector;
	private String cardsAvaliableGoalCSSSelector;
	private String saveValueCSSSelector;
	private HashMap<String, String> calculationResult;
	
	@BeforeTest
	private void setupTest() {
		//Method - setup test parameters and environment
		clearScoreLogic	 = new ClearScoreLogic();
		scoreSliderCSSSelector = ".js-range-current";	
		currentScoreSliderValueCSSSelector = ".js-range-current-val";
		websiteURL = "https://clearscore.com/savings-calculator";
		cookieButtonCSSSelector = ".accept-cookies";
		goalSliderCSSSelector = ".js-range-goal";
		currentGoalSliderValueCSSSelector = ".js-range-goal-val";
		averageInterestCurrentCSSSelector = ".js-current-average-rate";
		averageInterestGoalCSSSelector = ".js-goal-average-rate";
		annualCostCurrentCSSSelector = ".js-current-annual-cost";
		annualCostGoalCSSSelector = ".js-goal-annual-cost";
		cardsAvaliableCurrentCSSSelector = ".js-current-cc-available";
		cardsAvaliableGoalCSSSelector = ".js-goal-cc-available";
		saveValueCSSSelector = ".js-total-saving-number";
		//navigate website, select slider values and store calculation result
		try {
			clearScoreLogic.resetTest(websiteURL);
			clearScoreLogic.hideCookieBanner(cookieButtonCSSSelector); //simulating normal user behaviour
			clearScoreLogic.setSlider(scoreSliderCSSSelector, currentScoreSliderValueCSSSelector, 50); //score slider
			clearScoreLogic.setSlider(goalSliderCSSSelector, currentGoalSliderValueCSSSelector, 680); //goal slider
			//get and store result
			calculationResult = clearScoreLogic.getCorrectCalculatorValues(averageInterestCurrentCSSSelector,
					averageInterestGoalCSSSelector, annualCostCurrentCSSSelector, annualCostGoalCSSSelector, cardsAvaliableCurrentCSSSelector, 
					cardsAvaliableGoalCSSSelector, saveValueCSSSelector);
		}
		catch (Exception e) {
			//if slider cannot be set (will be reported in TestNG output so no extra formatting/logging required)
			e.printStackTrace();
		}
	}
		
	@Test (description = "Is Average Calculation Correct?")
	private void runTest1() {
		//Test 1 - Check if average calculation is correct 
		Assert.assertEquals(calculationResult.get("averageInterestCurrent"), "36.5%");
		Assert.assertEquals(calculationResult.get("annualCostCurrent"), "�849");
		Assert.assertEquals(calculationResult.get("cardsAvaliableCurrent"), "22");
	}	
	
	@Test (description = "Is Goal Calculation Correct?")
	private void runTest2() {
		//Test 2 - Check if goal calculation is correct 
		Assert.assertEquals(calculationResult.get("averageInterestGoal"), "25%");
		Assert.assertEquals(calculationResult.get("annualCostGoal"), "�520");
		Assert.assertEquals(calculationResult.get("cardsAvaliableGoal"), "241");
	}
	
	@Test (description = "Is Saving Calculation Correct?")
	private void runTest3() {
		//Test 3 - Check if saving amount is correct 
		Assert.assertEquals(calculationResult.get("saveValue"), "�384*");
	}
	
	@AfterTest
	private void endTest() {
		//Method - clear up test resources
		clearScoreLogic.clearUpResources();
	}
}
