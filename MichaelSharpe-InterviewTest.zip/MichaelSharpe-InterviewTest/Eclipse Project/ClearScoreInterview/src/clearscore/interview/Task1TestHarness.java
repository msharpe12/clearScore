/*
 * Author: Michael Sharpe
 * Project: ClearScore Interview
 * Date: 10/11/2018 
 * 
 * Note: Test result output to 'TestResultOutput' folder within project
 * Dependencies: TestNG and Selenium
 */

package clearscore.interview;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Task1TestHarness {
	
	private ClearScoreLogic clearScoreLogic;
	private String cookieCSSSelector;
	private String websiteURL;
	private String cookieButtonCSSSelector;
	private String externalWebsiteURL;
	private String internalWebsiteURL;

	@BeforeTest
	private void setupTest() {
		//Method - setup test parameters and environment
		clearScoreLogic	 = new ClearScoreLogic();
		cookieCSSSelector = ".cs-cookie";
		websiteURL = "https://www.clearscore.com/";
		cookieButtonCSSSelector = ".accept-cookies";
		externalWebsiteURL = "https://www.google.com/";
		internalWebsiteURL = "https://www.clearscore.com/about-us";
	}
		
	@Test (description = "Is Cookie Banner Shown?")
	private void runTest1() {
		//Test 1 - Is Cookie Banner Shown?
		clearScoreLogic.resetTest(websiteURL);
		Assert.assertEquals(true, clearScoreLogic.isCookieBannerDisplayed(cookieCSSSelector));
	}
	
	@Test(description = "Is Cookie Banner Hidden After Button 'No Problem' Clicked?")
	private void runTest2() {
		//Test 2 - Is Cookie Banner Hidden After Button 'No Problem' Clicked?
		clearScoreLogic.resetTest(websiteURL);
		clearScoreLogic.hideCookieBanner(cookieButtonCSSSelector);
		Assert.assertEquals(false, clearScoreLogic.isCookieBannerDisplayed(cookieCSSSelector));	
	}
	
	@Test(description = "Is Cookie Banner Still Hidden After Navigation?")
	private void runTest3() {
		//Test 3 - Is Cookie Banner Still Hidden After Navigation
		clearScoreLogic.resetTest(websiteURL);
		clearScoreLogic.hideCookieBanner(cookieButtonCSSSelector);
		//test an internal link
		clearScoreLogic.navigate((internalWebsiteURL));
		clearScoreLogic.navigate((websiteURL));
		Assert.assertEquals(false, clearScoreLogic.isCookieBannerDisplayed(cookieCSSSelector));	
		//test an external link
		clearScoreLogic.navigate(externalWebsiteURL);
		clearScoreLogic.navigate(websiteURL);		
		Assert.assertEquals(false, clearScoreLogic.isCookieBannerDisplayed(cookieCSSSelector));			
	}
	
	@Test (description = "Are appropriate cookies set?" )
	private void runTest4() {
		//TEST 4 - Are appropriate cookies set?
		clearScoreLogic.resetTest(websiteURL);
		Assert.assertEquals(true, clearScoreLogic.cookieValuePopulated("CS_PERSON"));	
		Assert.assertEquals(true, clearScoreLogic.cookieValuePopulated("CS_FIRST_VISIT"));	
		Assert.assertEquals(true, clearScoreLogic.cookieValuePopulated("CS_VISITED_SITE"));	
	}
	
	@AfterTest
	private void endTest() {
		clearScoreLogic.clearUpResources();
	}
}
