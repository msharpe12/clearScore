/*
 * Author: Michael Sharpe
 * Project: ClearScore Interview
 * Date: 10/11/2018 
 * 
 * Dependencies: Selenium
 */

package clearscore.interview;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClearScoreLogic {

	private static WebDriver driver;
	
	public ClearScoreLogic() {
		//Object constructor
		System.setProperty("webdriver.chrome.driver", ".\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS); 
		driver.manage().window().maximize();
	}
	
	public boolean isCookieBannerDisplayed(String cssSelector) {
		//Method - attain the cookie banner and return displayed state
		return driver.findElement(By.cssSelector(cssSelector)).isDisplayed();	
	}
	
	public void hideCookieBanner(String cssSelector) {
		//Method - attain the cookie banner button and perform action
		WebElement cookieButton = driver.findElement(By.cssSelector(cssSelector));
		cookieButton.click();
	}
	
	public boolean cookieValuePopulated(String cookieName) {
		//Method - Get value of cookie name passed and return false if not populated	
		String cookieValue = driver.manage().getCookieNamed(cookieName).getValue();
		if (cookieValue != "") {
				return true;
			}
		return false;
	}
	
	public void resetTest(String websiteURL) {
		//Method - set starting point of test
		driver.manage().deleteAllCookies();
		driver.navigate().to(websiteURL);
	}
	
	public void clearUpResources() {
		//Method - clear up web driver resource
		driver.quit();
	}
	
	public void navigate(String websiteURL) {
		//Method - Navigate to URL passed
		driver.navigate().to(websiteURL);
	}
	
	public void setSlider(String sliderCSSSelector, String sliderValueCSSSelector, int targetValue) throws Exception {
		//Method - set slider to desired value
		
		WebElement slider = driver.findElement(By.cssSelector(sliderCSSSelector));
		WebElement sliderValue = driver.findElement(By.cssSelector(sliderValueCSSSelector));

		int loopCount = 0;
		//loop until value has been set (if max limit reached break loop to prevent forever looping)
		while (Integer.parseInt(sliderValue.getText()) != targetValue) {
			//reduce slide value -1 until value reached
			loopCount++;
			slider.sendKeys(Keys.ARROW_LEFT);
			if (Integer.parseInt(sliderValue.getText()) == 0) {
				while (Integer.parseInt(sliderValue.getText()) != targetValue) {
					//increase slide value +1 until value reached
					loopCount++;
					slider.sendKeys(Keys.ARROW_RIGHT);
					if (loopCount == 1401) {
						//reached all possible point on slider so raise exception as still not met the value
						throw new Exception("Slider Cannot Be Set");
					}
				}
			}
			//reached all possible point on slider so raise exception as still not met the value
			else if (loopCount == 1401) {
				throw new Exception("Slider Cannot Be Set");
			}
		}
	}
	
	public HashMap<String, String> getCorrectCalculatorValues(String averageInterestCurrentCSSSelector, String averageInterestGoalCSSSelector,
			String annualCostCurrentCSSSelector, String annualCostGoalCSSSelector, String cardsAvaliableCurrentCSSSelector, 
			String cardsAvaliableGoalCSSSelector, String saveValueCSSSelector) {
		//Method - get calculator values and store in a map
		HashMap<String, String> calculatorValues = new HashMap<String, String>(); 
		
		//add each desired calculator output and value to the map
		calculatorValues.put("averageInterestCurrent",  driver.findElement(By.cssSelector(averageInterestCurrentCSSSelector)).getText());
		calculatorValues.put("averageInterestGoal",  driver.findElement(By.cssSelector(averageInterestGoalCSSSelector)).getText());
		calculatorValues.put("annualCostCurrent",  driver.findElement(By.cssSelector(annualCostCurrentCSSSelector)).getText());
		calculatorValues.put("annualCostGoal",  driver.findElement(By.cssSelector(annualCostGoalCSSSelector)).getText());
		calculatorValues.put("cardsAvaliableCurrent",  driver.findElement(By.cssSelector(cardsAvaliableCurrentCSSSelector)).getText());
		calculatorValues.put("cardsAvaliableGoal",  driver.findElement(By.cssSelector(cardsAvaliableGoalCSSSelector)).getText());
		calculatorValues.put("saveValue",  driver.findElement(By.cssSelector(saveValueCSSSelector)).getText());
		
		return calculatorValues;
	}
}
