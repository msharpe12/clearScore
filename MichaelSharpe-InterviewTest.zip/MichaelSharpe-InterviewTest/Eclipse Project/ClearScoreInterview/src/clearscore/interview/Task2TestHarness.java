/*
 * Author: Michael Sharpe
 * Project: ClearScore Interview
 * Date: 10/11/2018 
 * 
 * Note: Test result output to 'TestResultOutput' folder within project
 * Dependencies: TestNG and RestAssured
 */

package clearscore.interview;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;

public class Task2TestHarness {
	
	private String apiTestURL;
	
	@BeforeTest
	private void setupTest() {
		//Method - setup test parameters
		apiTestURL = "https://api.clearscore.com/profile-service/v2/";
	}
	
	@Test (description = "Does response code 403 return from API https://api.clearscore.com/profile-service/v2/ ?")
	private void runTest1() {
		//setup request headers
		RequestSpecification request = given().header(
				 "Host", "api.clearscore.com").header(
				 "User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0").header(
				 "Accept", "application/json, text/plain, */*").header( 
				 "Accept-Language", "en-US,en;q=0.5").header( 
				 "Accept-Encoding", "gzip, deflate, br").header(
				 "Referer", "https://www.clearscore.com/account/").header( 
				 "Authorization", "Bearer undefined").header( 
				 "X-CS-Device", "desktop").header(
				 "Origin", "https://www.clearscore.com").header( 
				 "Connection", "keep-alive").header(
				 "TE", "Trailers"
				 );
		//call api and check result
		request.when().get(apiTestURL).then().statusCode(403);
	}
}